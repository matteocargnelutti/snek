"""
Snek - A dead-simple static-site generator for Python.
v0.1 - "Danger noodle" | https://github.com/matteocargnelutti/snek

snek.__init__.py: Snek package entry point
"""
#-------------------------------------------------------------------------------
# Imports
#-------------------------------------------------------------------------------
from snek.snek import Snek
from snek.snekconfig import SnekConfig
